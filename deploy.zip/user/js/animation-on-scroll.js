// $(window).scroll(function() {    
//     var scroll = $(window).scrollTop();
//      //>=, not <=
//     //  hideLogoOnFooter()
//     if (scroll >= 1200) {
//         //clearHeader, not clearheader - caps H
//         // $(".clearHeader").addClass("card");
//         // $(".clearHeader").addClass("card");
//         $( "#card1" ).removeClass("d-none")
//         $( "#card2" ).removeClass("d-none")
//         $( "#card3" ).removeClass("d-none")
//         $( "#card4" ).removeClass("d-none")
//     }
//     else
//     {
//         $( "#card1" ).addClass("d-none")
//         $( "#card2" ).addClass("d-none")
//         $( "#card3" ).addClass("d-none")
//         $( "#card4" ).addClass("d-none")
//     }
// }); 

// // function hideLogoOnFooter() {
// //     console.log("fn run")
// //     if($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
// //         console.log("fn if")
// //         "use strict"; 
// //         document.getElementById("logo").style.display = "none"
// //     }
// //     else
// //     {
// //         console.log("fn else")
// //         document.getElementById("logo").style.display = "block"
// //     }
// // }
