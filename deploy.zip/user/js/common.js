function goToHomePage() {
    window.location.href = "index.html"
}

// var vid = document.getElementById("logo__video");

// $(window).scroll(function () {
//     var scroll = $(window).scrollTop();
//     //>=, not <=
//     if (scroll < 300) {
//         vid.play()
//     }
// });
