var firebaseConfig = {
    apiKey: "AIzaSyCIVaKkyDrCu3BA0I8gPkL7zf62BfgrbiE",
    authDomain: "admin-pyshef.firebaseapp.com",
    databaseURL: "https://admin-pyshef.firebaseio.com",
    projectId: "admin-pyshef",
    storageBucket: "admin-pyshef.appspot.com",
    messagingSenderId: "397027328547",
    appId: "1:397027328547:web:7de5bb1283f78b77072796",
    measurementId: "G-CM9T01PH8R"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);