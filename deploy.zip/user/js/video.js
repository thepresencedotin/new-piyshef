// var figure = $(".video").hover(hoverVideo, hideVideo);
// // var figure2 = $(".video2").hover( hoverVideo2, hideVideo2 );
// var aboutVid = document.getElementById("about-video");
// var aboutVideoStatus = false


// function hoverVideo(e) {
//     $('#logo').hide()
//     $('video', this).get(0).play();
// }

// function hideVideo(e) {
//     $('#logo').show()
// }

// function hoverVideo2(e) {
//     $('video', this).get(0).play();
// }


// function playVideo() {
//     aboutVideoStatus = !aboutVideoStatus
//     if (aboutVideoStatus) {
//         aboutVid.play()
//     }
//     else {
//         aboutVid.pause()
//     }
// }



// var player;


function showMutedVideo() {
    let video = document.getElementById("modal-video")
    video.pause()
    document.getElementById("mutedVideo").style.opacity = 1
    player.pauseVideo();
}

function modalVideoPlay() {
    var playButton = document.getElementById("play-button");
    document.getElementById("mutedVideo").style.opacity = 0
    let video = document.getElementById("modal-video")
    video.play()
}
